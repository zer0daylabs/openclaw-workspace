# Freqtrade Example Strategy - Simple RSI & MACD
# This is a simple example strategy for dry-run testing

from freqtrade.strategy import IStrategy, IntParameter, BooleanParameter
from pandas import DataFrame
import freqtrade.vendor.qtpylib.indicators as qtpylib


class RsiMacD(IStrategy):
    """
    Simple RSI + MACD crossover strategy
    For dry-run testing only
    """

    INTERFACE_VERSION = 3
    PROCESS_ONLY_NEW_CANDLES = True
    BACKTESTING_ENABLED = True
    CAN_START_MISSING = False

    # Minimal stake amount
    MINIMAL_CONFIG = {
        'stake_amount': 10.0,
    }

    DEFUNTIMEOUT = 10

    # Parameters
    buy_rsi_period = IntParameter(default=14, low=7, high=21, space='buy')
    buy_rsi_value = IntParameter(default=30, low=20, high=40, space='buy')
    sell_rsi_period = IntParameter(default=14, low=7, high=21, space='sell')
    sell_rsi_value = IntParameter(default=70, low=60, high=80, space='sell')

    # Required method for Freqtrade strategies
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Populate indicators for buy/sell signals"""
        # Calculate RSI
        for period in [self.buy_rsi_period.value, self.sell_rsi_period.value]:
            dataframe[f'rsi_{period}'] = qtpylib.rsi(dataframe['close'], window=period)
        
        # Calculate MACD
        macd_val, macdsignal_val, macdhist_val = qtpylib.macd(dataframe['close'])
        dataframe['macd'] = macd_val
        dataframe['macdsignal'] = macdsignal_val
        dataframe['macdhist'] = macdhist_val
        
        return dataframe

    # Buy signal
    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Buy signal conditions"""
        # Calculate RSI value column
        rsi_col = f"rsi_{self.buy_rsi_period.value}"
        dataframe.loc[
            qtpylib.crossed_below(
                dataframe[rsi_col], self.buy_rsi_value.value
            ),
            'buy'] = 1
        return dataframe

    # Sell signal
    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Sell signal conditions"""
        rsi_col = f"rsi_{self.sell_rsi_period.value}"
        dataframe.loc[
            qtpylib.crossed_above(
                dataframe[rsi_col], self.sell_rsi_value.value
            ),
            'sell'] = 1
        return dataframe
