# Freqtrade Example Strategy - Simple RSI & MACD
# This is a simple example strategy for dry-run testing

from freqtrade.strategy import IStrategy, IntParameter, merge_informative_pair
from pandas import DataFrame
from datetime import datetime, timedelta, timezone
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class RsiMacD(IStrategy):
    """
    v7 — Adaptive dual-mode strategy
    Mode A (ADX < 25, ranging): Mean-reversion — buy RSI oversold, exit at mean
    Mode B (ADX > 25, trending): Trend-following — buy EMA crossover + momentum
    Risk: -3% stoploss, graduated exits, 4h force-exit
    """

    INTERFACE_VERSION = 3
    PROCESS_ONLY_NEW_CANDLES = True

    # Increased for 1h EMA(50) warmup via informative pairs
    startup_candle_count = 50

    # Tighter ROI: take profits faster on small moves
    minimal_roi = {
        "0": 0.02,    # 2% profit anytime
        "30": 0.01,   # 1% after 30 min
        "60": 0.005,  # 0.5% after 1 hour
    }

    stoploss = -0.03

    # Trailing stop: lock in profits once trade is up 1%
    trailing_stop = True
    trailing_stop_positive = 0.005          # 0.5% trail distance
    trailing_stop_positive_offset = 0.01    # activate after 1% profit
    trailing_only_offset_is_reached = True

    # Parameters
    buy_rsi_period = IntParameter(default=14, low=7, high=21, space='buy')
    buy_rsi_value = IntParameter(default=30, low=20, high=40, space='buy')
    sell_rsi_period = IntParameter(default=14, low=7, high=21, space='sell')
    sell_rsi_value = IntParameter(default=70, low=60, high=80, space='sell')

    def informative_pairs(self):
        """Define 1h pairs for trend filter"""
        pairs = self.dp.current_whitelist()
        return [(pair, '1h') for pair in pairs]

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Populate indicators for buy/sell signals"""
        # 5m RSI
        for period in [self.buy_rsi_period.value, self.sell_rsi_period.value]:
            dataframe[f'rsi_{period}'] = qtpylib.rsi(dataframe['close'], window=period)
        
        # 5m MACD (returns DataFrame with 'macd', 'signal', 'histogram' columns)
        macd_df = qtpylib.macd(dataframe['close'])
        dataframe['macd'] = macd_df['macd']
        dataframe['macdsignal'] = macd_df['signal']
        dataframe['macdhist'] = macd_df['histogram']

        # Bollinger Bands (20-period, 2 std dev)
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_middleband'] = bollinger['mid']
        dataframe['bb_upperband'] = bollinger['upper']

        # Volume moving average (20-period) for volume filter
        dataframe['volume_mean_20'] = dataframe['volume'].rolling(window=20).mean()

        # ADX — trend strength (switches between modes)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        # EMA crossover for trend-following mode
        dataframe['ema9'] = dataframe['close'].ewm(span=9, adjust=False).mean()
        dataframe['ema21'] = dataframe['close'].ewm(span=21, adjust=False).mean()
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14)

        # Bullish candlestick patterns (ta-lib returns 0/100/-100)
        dataframe['cdl_engulfing'] = ta.CDLENGULFING(dataframe)
        dataframe['cdl_hammer'] = ta.CDLHAMMER(dataframe)
        dataframe['cdl_morningstar'] = ta.CDLMORNINGSTAR(dataframe)
        dataframe['cdl_dragonfly'] = ta.CDLDRAGONFLYDOJI(dataframe)
        dataframe['cdl_invertedhammer'] = ta.CDLINVERTEDHAMMER(dataframe)
        dataframe['cdl_piercing'] = ta.CDLPIERCING(dataframe)
        # Combined: any bullish pattern present (value > 0 = bullish)
        dataframe['bullish_candle'] = (
            (dataframe['cdl_engulfing'] > 0) |
            (dataframe['cdl_hammer'] > 0) |
            (dataframe['cdl_morningstar'] > 0) |
            (dataframe['cdl_dragonfly'] > 0) |
            (dataframe['cdl_invertedhammer'] > 0) |
            (dataframe['cdl_piercing'] > 0)
        ).astype(int)

        # 1h EMA(50) trend filter
        if self.dp:
            informative = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe='1h')
            informative['ema50'] = informative['close'].ewm(span=50, adjust=False).mean()
            informative['ema50_slope'] = informative['ema50'] - informative['ema50'].shift(1)
            dataframe = merge_informative_pair(dataframe, informative, self.timeframe, '1h', ffill=True)

        return dataframe

    # Entry signal
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Test C: Selective EMA crossover + filters"""
        dataframe.loc[
            (
                (qtpylib.crossed_above(dataframe['ema9'], dataframe['ema21'])) &
                (dataframe['macdhist'] > 0) &
                (dataframe['adx'] > 20) &
                (dataframe['volume'] > dataframe['volume_mean_20']) &
                (dataframe['ema50_slope_1h'] >= 0) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']] = (1, 'ema_cross_filtered')

        return dataframe

    def custom_exit(self, pair: str, trade, current_time: datetime,
                    current_rate: float, current_profit: float, **kwargs):
        """Test C: Minimal custom exit — let ROI/trailing/stoploss handle most exits."""
        trade_duration = (current_time - trade.open_date_utc).total_seconds() / 3600

        # Force-exit red trades after 6h (give trends more room)
        if trade_duration >= 6 and current_profit < 0:
            return 'force_exit_6h'

        # Lock in profits > 0.5% after 30min
        if current_profit > 0.005 and trade_duration >= 0.5:
            return 'profit_protect'

        return None

    # Exit signal
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Test B: No exit signal — rely on ROI/trailing/stoploss/custom_exit only"""
        return dataframe
